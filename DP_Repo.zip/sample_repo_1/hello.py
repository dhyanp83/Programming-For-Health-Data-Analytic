
def howdy():
    print("Hello there, hope you are having a great week!")


if __name__ == '__main__':
    howdy()


