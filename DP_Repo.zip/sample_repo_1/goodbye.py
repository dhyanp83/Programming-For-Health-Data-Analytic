
def say_goodbye():
    print("See you later, have a great week!")


if __name__ == '__main__':
    say_goodbye()
